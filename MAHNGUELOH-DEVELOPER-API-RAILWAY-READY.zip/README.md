# MAHNGUELOH Developer API — Railway Ready

A Node.js/Express API and web dashboard for retrieving files from **publicly accessible HTTP/HTTPS URLs**.

It does not bypass authentication, DRM, paywalls, private resources, or other access controls.

## Deploy on Railway

1. Upload this project to a GitHub repository.
2. In Railway, create a new project and deploy the GitHub repository.
3. Railway will use `railway.json` and run `npm start`.
4. Add these variables in Railway:
   - `ADMIN_API_KEY` — a long random secret used only for admin key creation.
   - `MAX_FILE_MB` — e.g. `100`.
   - `DOWNLOAD_TIMEOUT_MS` — e.g. `30000`.
   - `FILE_TTL_SECONDS` — e.g. `3600`.
   - `RATE_LIMIT_PER_MINUTE` — e.g. `60`.
   - Optional: `DEMO_API_KEY=demo_mahngueloh_key` for quick testing.
5. Deploy. Open the generated Railway domain.
6. Test `/health` first.

Do **not** set a fixed `PORT`; Railway provides it automatically.

## Create a developer API key

Send an admin-authenticated request:

`POST /api/keys`

Header:

`Authorization: Bearer YOUR_ADMIN_API_KEY`

JSON body:

`{"name":"My Developer"}`

The response contains the new API key. Store it securely.

## Download endpoint

`POST /v1/download`

Headers:

`Authorization: Bearer YOUR_API_KEY`
`Content-Type: application/json`

Body:

`{"url":"https://example.com/file.zip"}`

The response returns a temporary `download_url`.

## Important Railway storage note

Downloaded files are stored in the service's local temporary filesystem and expire automatically. They can disappear when the Railway service restarts or is redeployed. This version intentionally treats downloaded files as temporary delivery artifacts rather than permanent storage.

## Security notes

- Keep `ADMIN_API_KEY` private.
- Do not commit `.env`.
- Use only URLs you are authorized to retrieve.
- The API accepts HTTP/HTTPS only and limits redirects, size, and timeout.
