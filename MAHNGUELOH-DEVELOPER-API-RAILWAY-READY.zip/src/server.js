require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_MB = Number(process.env.MAX_FILE_MB || 100);
const MAX_BYTES = MAX_MB * 1024 * 1024;
const TIMEOUT = Number(process.env.DOWNLOAD_TIMEOUT_MS || 30000);
const FILE_TTL = Number(process.env.FILE_TTL_SECONDS || 3600);
const RATE = Number(process.env.RATE_LIMIT_PER_MINUTE || 60);
const BASE_URL = process.env.BASE_URL || '';
const ADMIN_API_KEY = process.env.ADMIN_API_KEY || '';
const TMP = path.join(__dirname, '..', 'temp');
fs.mkdirSync(TMP, { recursive: true });

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit({ windowMs: 60000, max: RATE, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, '..', 'public')));

const stats = { requests: 0, downloads: 0, bytes: 0, started: Date.now() };
const files = new Map();
const keys = new Map();

function makeKey(prefix = 'mhg') {
  return `${prefix}_${crypto.randomBytes(24).toString('hex')}`;
}

if (process.env.DEMO_API_KEY) {
  keys.set(process.env.DEMO_API_KEY, { name: 'Demo Developer', created: Date.now(), requests: 0 });
}

function validUrl(value) {
  try {
    const u = new URL(value);
    return ['http:', 'https:'].includes(u.protocol) ? u : null;
  } catch { return null; }
}

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return res.status(401).json({ success: false, error: 'API key required' });
  const key = h.slice(7).trim();
  const item = keys.get(key);
  if (!item) return res.status(401).json({ success: false, error: 'Invalid API key' });
  item.requests++;
  req.apiKey = key;
  next();
}

function adminAuth(req, res, next) {
  if (!ADMIN_API_KEY) return res.status(503).json({ success: false, error: 'Admin API key is not configured' });
  const h = req.headers.authorization || '';
  if (h !== `Bearer ${ADMIN_API_KEY}`) return res.status(403).json({ success: false, error: 'Admin authorization required' });
  next();
}

function safeName(url, headers) {
  let n = 'download';
  const cd = headers['content-disposition'] || '';
  const m = cd.match(/filename\*?=(?:UTF-8'')?["']?([^;"']+)/i);
  if (m) { try { n = decodeURIComponent(m[1]); } catch { n = m[1]; } }
  else { try { n = path.basename(new URL(url).pathname) || n; } catch {} }
  return n.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 160) || 'download';
}

function getStream(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error('Too many redirects'));
    const u = new URL(url);
    const client = u.protocol === 'https:' ? https : http;
    const req = client.get(u, { headers: { 'User-Agent': 'MAHNGUELOH-Developer-API/1.1', Accept: '*/*' } }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();
        if (!res.headers.location) return reject(new Error('Redirect without location'));
        return resolve(getStream(new URL(res.headers.location, url).href, redirects + 1));
      }
      resolve({ res, req });
    });
    req.setTimeout(TIMEOUT, () => req.destroy(new Error('Download timeout')));
    req.on('error', reject);
  });
}

async function downloadUrl(url) {
  const { res } = await getStream(url);
  if (res.statusCode < 200 || res.statusCode >= 300) {
    res.resume();
    throw new Error(`Remote server returned HTTP ${res.statusCode}`);
  }
  const length = Number(res.headers['content-length'] || 0);
  if (length > MAX_BYTES) {
    res.resume();
    throw new Error(`File exceeds ${MAX_MB} MB limit`);
  }

  const id = crypto.randomBytes(12).toString('hex');
  const name = safeName(url, res.headers);
  const filePath = path.join(TMP, `${id}-${name}`);

  return await new Promise((resolve, reject) => {
    let total = 0;
    let settled = false;
    const out = fs.createWriteStream(filePath);
    const fail = err => {
      if (settled) return;
      settled = true;
      res.destroy();
      out.destroy();
      try { fs.unlinkSync(filePath); } catch {}
      reject(err);
    };
    res.on('data', chunk => {
      total += chunk.length;
      if (total > MAX_BYTES) fail(new Error(`File exceeds ${MAX_MB} MB limit`));
    });
    res.on('error', fail);
    out.on('error', fail);
    out.on('finish', () => {
      if (settled) return;
      settled = true;
      resolve({ id, name, size: total, path: filePath, type: res.headers['content-type'] || 'application/octet-stream' });
    });
    res.pipe(out);
  });
}

app.get('/health', (req, res) => res.json({ success: true, status: 'healthy', service: 'MAHNGUELOH Developer API', version: '1.1.0', uptime: Math.floor(process.uptime()) }));
app.get('/api/stats', (req, res) => res.json({ success: true, stats: { requests: stats.requests, downloads: stats.downloads, bytes: stats.bytes, active_files: files.size, uptime: Math.floor((Date.now() - stats.started) / 1000) } }));

app.post('/api/keys', adminAuth, (req, res) => {
  const key = makeKey();
  const name = String(req.body?.name || 'Developer').slice(0, 80);
  keys.set(key, { name, created: Date.now(), requests: 0 });
  res.json({ success: true, name, key });
});

app.get('/api/keys', adminAuth, (req, res) => {
  const data = [...keys.entries()].map(([key, item]) => ({ key: `${key.slice(0, 10)}...`, name: item.name, created: item.created, requests: item.requests }));
  res.json({ success: true, keys: data });
});

app.post('/v1/download', auth, async (req, res) => {
  stats.requests++;
  const u = validUrl(req.body?.url);
  if (!u) return res.status(400).json({ success: false, error: 'A valid HTTP/HTTPS URL is required' });
  try {
    const f = await downloadUrl(u.href);
    files.set(f.id, { ...f, expires: Date.now() + FILE_TTL * 1000 });
    stats.downloads++;
    stats.bytes += f.size;
    const base = BASE_URL || `${req.protocol}://${req.get('host')}`;
    res.json({ success: true, id: f.id, filename: f.name, size: f.size, content_type: f.type, expires_in: FILE_TTL, download_url: `${base}/files/${f.id}` });
  } catch (e) {
    res.status(400).json({ success: false, error: e.message || 'Download failed' });
  }
});

app.get('/files/:id', (req, res) => {
  const f = files.get(req.params.id);
  if (!f || f.expires < Date.now()) {
    if (f) { try { fs.unlinkSync(f.path); } catch {} files.delete(req.params.id); }
    return res.status(404).json({ success: false, error: 'File not found or expired' });
  }
  res.download(f.path, f.name);
});

app.get('/api/docs', (req, res) => res.json({
  name: 'MAHNGUELOH Developer API', version: '1.1.0', authentication: 'Bearer API key',
  endpoints: [
    { method: 'GET', path: '/health', auth: false },
    { method: 'POST', path: '/v1/download', auth: true, body: { url: 'https://example.com/file.zip' } },
    { method: 'GET', path: '/files/:id', auth: false },
    { method: 'GET', path: '/api/stats', auth: false },
    { method: 'GET', path: '/api/docs', auth: false }
  ],
  limits: { max_file_mb: MAX_MB, timeout_ms: TIMEOUT, file_ttl_seconds: FILE_TTL }
}));

app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

setInterval(() => {
  for (const [id, f] of files) {
    if (f.expires < Date.now()) { try { fs.unlinkSync(f.path); } catch {} files.delete(id); }
  }
}, 10 * 60 * 1000).unref();

app.listen(PORT, () => console.log(`MAHNGUELOH Developer API listening on :${PORT}`));
